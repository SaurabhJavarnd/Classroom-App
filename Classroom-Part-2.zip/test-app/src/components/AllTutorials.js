import React, { useState, useEffect } from "react";
import axios from "axios";
import cogoToast from "cogo-toast";

const AllTutorials = ({tutorials, getAllData}) => {
  
useEffect(() => {
  
}, [tutorials])
  
  
  
function getAllData() {
  axios.get("http://localhost:8080/api/v1/tutorials/").then((response) => {
    console.log(response);
    if (response.status === 200) {
      cogoToast.success("Data Successfully Loaded");
      setTutorials(response.data.title);
    } else {
      cogoToast.error("This is a error message");
      setTutorials([]);
    }
  });
  console.log(tutorials);
}
useEffect(() => {
  getAllData();
}, []);

  const deleteTutorial = (id) => {
    axios
      .delete(`http://localhost:8080/api/v1/tutorials/${id}`)
      .then((response) => {
        if (response.status === 200) {
          cogoToast.warn("Deleted Successfully").then(()=>{
            getAllData();
          });
        } 
      }).then(()=>{
        getAllData();
      })
  };
  
  

  return (
    <div className="register">
      <h4>All Tutorials</h4>
      {tutorials &&
        tutorials?.map((item, index) => {
          return (
            <div key={index}>
              <p>{item.title}</p>
              <button 
                onClick={() => {
                  console.log(item.title);
                  getAllData();
                }}
                type="button" className="btn btn-light"
                id="edit"
              >
                Edit
              </button>
              <button
                onClick={(refresh) => {
                  console.log(item._id);
                  deleteTutorial(item._id);
                }}
                type="button" className = "btn btn-danger m-2"
                id="delete"
              >
                Delete
              </button>
            </div>
          );
        })}
    </div>
  );
};

export default AllTutorials;
