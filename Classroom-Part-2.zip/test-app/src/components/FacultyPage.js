import React, { useState, useEffect } from "react";
import axios from "axios";
import cogoToast from "cogo-toast";
import AllTutorials from "./AllTutorials";

const FacultyPage = () => {
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("");
  const [standard, setStandard] = useState("");
  const [file, setFile] = useState("");
  const [tutorials, setTutorials] = useState([]);

  function getAllData() {
    axios.get("http://localhost:8080/api/v1/tutorials/").then((response) => {
      console.log(response);
      if (response.status === 200) {
        cogoToast.success("Data Successfully Loaded");
        setTutorials(response.data.data.tutorials);
      } else {
        cogoToast.error("This is a error message");
        setTutorials([]);
      }
    });
    console.log(tutorials);
  }
  useEffect(() => {
    getAllData();
  }, []);

  const data = async () => {
    let userData = {
      title: title,
      subject: subject,
      standard: standard,
      file: file,
    };
    let result = await axios.post(
      "http://localhost:8080/api/v1/tutorials/",
      userData
    );
    localStorage.setItem("user", JSON.stringify(result));
    console.log(result);
    if (result.data.status === "success") {
      cogoToast.success("Data Successfully Loaded").then(() => {
        getAllData();
      });
    } else {
      cogoToast.error("This is a error message");
    }
  };

  return (
    <React.Fragment>
      <div className="container">
        <div className="row align-items-start">
          <div className="col">
            <h4>Welcome to Faculty Page</h4>
            <div>
              <input
                className="inputBox"
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Title"
              />
              <div className="">
                <input
                  className="inputBox"
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Subject"
                />
              </div>
              <input
                className="inputBox"
                type="text"
                value={standard}
                onChange={(e) => setStandard(e.target.value)}
                placeholder="Standard"
              />
              <input
                className="inputBox"
                type="text"
                value={file}
                onChange={(e) => setFile(e.target.value)}
                placeholder="file"
              />
              <button onClick={data} className="btn btn-primary" type="button">
                Submit
              </button>
            </div>
          </div>
  
          <div className="col">
            <AllTutorials tutorials={tutorials} getAllData={getAllData} />
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default FacultyPage;
