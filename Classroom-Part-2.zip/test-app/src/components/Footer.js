import React from 'react';

const Footer = () => {
    return (
        <div className="fixed-bottom col-md-6 offset-md-3">
            <h6>
                Created by Saurabh Krishan Gulab
            </h6>
        </div>
    );
};

export default Footer;