import './App.css';
import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import Home from './components/Home';
import {BrowserRouter, Routes, Route} from 'react-router-dom';
import SignUp from './components/SignUp';
import Login from './components/Login';
import Footer from './components/Footer';
import FacultyLogin from './components/FacultyLogin';
import StudentLogin from './components/StudentLogin';
import FacultyPage from './components/FacultyPage';
import StudentPage from './components/StudentPage';

function App() {
  const user = localStorage.getItem("user");
  
  return (
    <div className="App">
      <BrowserRouter>
      <Home/>
      <Routes>
        <Route path="/" element={user?.data?.user?.userType === "student" ? <StudentPage/> : <FacultyPage/>}/>
        <Route path="/login" element={<Login/>}/>
        <Route path="/studentlogin" element={<StudentLogin/>}/>
        <Route path="/facultylogin" element={<FacultyLogin/>}/>
        <Route path="/facultypage" element={<FacultyPage/>}/>
        <Route path="/studentpage" element={<StudentPage/>}/>
        <Route path="/signup" element={<SignUp/>} />
        <Route path="/facultypage/tutorial/:id" element={<h1>turorialid</h1>} />
      </Routes>
      <Footer/>
      </BrowserRouter>
    </div>
  );
};

export default App;

