const express = require('express');
const morgan = require('morgan'); //middleware to log HTTP requests and errors, and to simplify the process
const helmet = require('helmet'); //to secure HTTP headers
const mongoSanitize = require('express-mongo-sanitize'); ////a standalone module that sanitizes inputs against query selector injection attacks
const xss = require('xss-clean'); //to safeguard vulnerable websites to inject malicious code or a script
const cors = require('cors'); //Cross-Origin Resource Sharing - to remove error for security purpose

const globalErrorHandler = require('./controllers/errorController');
const userRouter = require('./routes/userRoutes');
const tutorialRouter = require('./routes/tutorialRoutes');
const questionRouter = require('./routes/questionRoutes');
const answerRouter = require('./routes/answerRoutes');

const app = express();

app.use(helmet()); 
app.use(
  cors({
    origin: '*',
  })
);

if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

app.use(express.json());

app.use(mongoSanitize()); 

app.use(xss()); //cross site scripting

app.use((req, res, next) => {
  req.requestTime = new Date().toISOString();
  next();
});

//ROUTES
app.use('/api/v1/users', userRouter);
app.use('/api/v1/tutorials', tutorialRouter);
app.use('/api/v1/question', questionRouter);
app.use('/api/v1/answer', answerRouter);

app.use(globalErrorHandler);

module.exports = app;
