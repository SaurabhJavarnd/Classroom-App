const express = require('express');
const questionController = require('../controllers/questionController');

const router = express.Router();

router.route("/").get(questionController.getQuestions).post(questionController.createQuestion);
router.route("/getById/:id").get(questionController.getQuestionsById);



module.exports = router;
