const express = require('express');
const answerController = require('../controllers/answerController');

const router = express.Router();

router.route("/").post(answerController.createAnswer);
router.route("/getById/:id").get(answerController.getAnswerById);

module.exports = router;
