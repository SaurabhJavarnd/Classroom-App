
const Answer = require('../models/answerModel');
// const AppError = require('../utils/appError');
const catchAsync = require('../utils/catchAsync');


exports.createAnswer = catchAsync(async (req, res, next) => {
    const answer = await Answer.create(req.body);
        res.status(201).json({
        status: 'success',
        data: {
            answer
        }
    });
});

exports.getAnswerById = catchAsync(async (req, res, next) => {
    const answer = await Answer.find().where('questionId').eq(req.params.id);
        res.status(200).json({
        status: 'success',
        data: {
            answer
        }
    });
});