
const Question = require('../models/QuestionModel');
// const AppError = require('../utils/appError');
const catchAsync = require('../utils/catchAsync');


exports.createQuestion = catchAsync(async (req, res, next) => {
    const question = await Question.create(req.body);
        res.status(201).json({
        status: 'success',
        data: {
            question
        }
    });
});

exports.getQuestions = catchAsync(async (req, res, next) => {
    const questions = await Question.find();
        res.status(200).json({
        status: 'success',
        data: {
            questions
        }
    });
});

exports.getQuestionsById = catchAsync(async (req, res, next) => {
    const questions = await Question.find().where('tutorialId').eq(req.params.id);
        res.status(200).json({
        status: 'success',
        data: {
            questions
        }
    });
})

