
const Tutorial = require('../models/tutorialModel');
const AppError = require('../utils/appError');
const catchAsync = require('../utils/catchAsync');

exports.getAllTutorials = catchAsync(async (req, res, next) => {
    const getTutorials = await Tutorial.find();
    res.status(200).json({
        status: 'success',
        data: {
            tutorials: getTutorials
        },
    });
});

exports.createTutorial = catchAsync(async (req, res, next) => {
    const newTutorials = await Tutorial.create(req.body);
    res.status(201).json({
        status: 'success',
        data: {
            tutorial: newTutorials
        },
      });
});

exports.getTutorial = catchAsync(async (req, res, next) => {
    const getTutorial = await Tutorial.findById(req.params.id);

    res.status(200).json({
        status: 'success',
        data: {
            tutorial: getTutorial
        },
    });
});

exports.updateTutorial = catchAsync(async (req, res, next) => {
    const updateTutorial = await Tutorial.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
        runValidators: true
    });
    if (!updateTutorial){
        return next(new AppError('No document found with ID', 404));
    } else {

        res.status(200).json({
        status: 'success',
        data: {
            tutorial: updateTutorial
        }
    });
}
});

exports.deleteTutorial = catchAsync(async (req, res, next) => {
    const deleteTutorial = await Tutorial.findByIdAndDelete(req.params.id);
    if(!deleteTutorial){
        return next(new AppError('No document found with ID', 404))
    } else {
    res.status(200).json({
        status: 'success',
        data: null
    });
    }
});
