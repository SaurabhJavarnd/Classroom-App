const mongoose = require('mongoose');
const validator = require('validator'); // used to check the validity or syntactical correctness of a fragment of code or document
const bcrypt = require('bcryptjs'); //for salt and hashing passwords

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Please tell us your name!'],
      unique: true,
      trim: true,
      maxLength: [10, 'Name must have less or equal than 10 characters'],
      minLength: [3, 'Name must have more or equal than 3 characters'],
    },
    contact: {
      type: String,
      required: [true, 'Please provide a valid contact'],
    },
    email: {
      type: String,
      required: [true, 'Email Required'],
      unique: true,
      lowercase: true,
      validate: [validator.isEmail, 'Please provide a valid email'],
    },
    username: {
      type: String,
      required: [true, 'Username Required'],
      unique: true,
    },
    password: {
      type: String,
      required: [true, 'Please provide a password'],
      minLength: [8, 'It should be more than 8 characters'],
      select: false,
    },
    userType: {
        type: String,
        required: [true, 'Please provide user type']
    },
    createdAt: {
      type: Date,
      default: Date.now(),
      select: false,
    },
    passwordChangedAt: Date,
  },
  {
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

userSchema.pre('save', async function (next) {
  //Only run this function if password is not modified
  if (!this.isModified('password')) return next();

  this.password = await bcrypt.hash(this.password, 12);
  next();
});

userSchema.methods.correctPassword = async function ( //to compare password
  candidatePassword,
  userPassword
) {
  return await bcrypt.compare(candidatePassword, userPassword);
};

const User = mongoose.model('User', userSchema);

module.exports = User;
