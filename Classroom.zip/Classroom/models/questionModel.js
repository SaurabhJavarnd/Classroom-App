const mongoose = require('mongoose');

const questionSchema = new mongoose.Schema(
    {
      question: {
        type: String,
        required: [true, 'Please Ask Something!'],
        unique: true,
        minLength: [3, 'Name must have more or equal than 3 characters'],
      },
      tutorialId: {
        type: String,
        required: [true]
    },
      userId: {
          type: String,
          required: [true, 'Please provide user ID']
      },
      createdAt: {
        type: Date,
        default: Date.now(),
        select: false,
      },
    },
    {
      toJSON: { virtuals: true },
      toObject: { virtuals: true },
    }
  );

  const Question = mongoose.model('Question', questionSchema);

module.exports = Question;