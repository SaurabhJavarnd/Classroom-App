const mongoose = require('mongoose');
const validator = require('validator');

const tutorialSchema = new mongoose.Schema(
    {
      title: {
        type: String,
        required: [true, 'Please Enter the title!'],
        unique: true,
        trim: true,
        maxLength: [10, 'Title must have less or equal than 10 characters'],
        minLength: [3, 'Title must have more or equal than 3 characters'],
      },
      subject: {
        type: String,
        required: [true, 'Please Enter the Subject!'],
      },
      standard: {
        type: Number,
        required: [true, 'Please Enter the Standard!'],
      },
      file: {
        type: String,
        required: [true, 'File Required'],
      },
      createdAt: {
        type: Date,
        default: Date.now(),
        select: false,
      },
    },
  );

const Tutorial = mongoose.model('Tutorials', tutorialSchema);

module.exports = Tutorial;
