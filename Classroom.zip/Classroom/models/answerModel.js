const mongoose = require('mongoose');

const answerSchema = new mongoose.Schema(
    {
      answer: {
        type: String,
        unique: true,
        minLength: [3, 'Name must have more or equal than 3 characters']
      },
      questionId: {
        type: String,
        required: [true]
    },
      userId: {
          type: String,
          required: [true, 'Please provide user ID']
      },
      createdAt: {
        type: Date,
        default: Date.now(),
        select: false,
      },
    },
    {
      toJSON: { virtuals: true },
      toObject: { virtuals: true },
    }
  );

  const Answer = mongoose.model('Answer', answerSchema);

module.exports = Answer;